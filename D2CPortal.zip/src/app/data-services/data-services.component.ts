import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-services',
  templateUrl: './data-services.component.html',
  styleUrls: ['./data-services.component.css']
})
export class DataServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
