import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-environment-services',
  templateUrl: './environment-services.component.html',
  styleUrls: ['./environment-services.component.css']
})
export class EnvironmentServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
