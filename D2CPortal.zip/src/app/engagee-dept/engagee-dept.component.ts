import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engagee-dept',
  templateUrl: './engagee-dept.component.html',
  styleUrls: ['./engagee-dept.component.css']
})
export class EngageeDeptComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
