import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-performance-engineering',
  templateUrl: './performance-engineering.component.html',
  styleUrls: ['./performance-engineering.component.css']
})
export class PerformanceEngineeringComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
