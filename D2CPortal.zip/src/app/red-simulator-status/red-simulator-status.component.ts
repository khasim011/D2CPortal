import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-red-simulator-status',
  templateUrl: './red-simulator-status.component.html',
  styleUrls: ['./red-simulator-status.component.css']
})
export class RedSimulatorStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
