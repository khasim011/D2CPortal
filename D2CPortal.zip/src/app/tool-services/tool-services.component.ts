import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tool-services',
  templateUrl: './tool-services.component.html',
  styleUrls: ['./tool-services.component.css']
})
export class ToolServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
