const config = {
	"Host": "https://khasimali.atlassian.net",
	"Jira_username": "khasim.ali@zensar.com",
    "Jira_password": "ZEns@r123"
};

module.exports = config;