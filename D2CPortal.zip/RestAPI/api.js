const express = require('express');
const router = express.Router();
const config = require('../config');
const request = require('request');

// Jira Login API
router.get('/login', (req, res) => {
    var obj = JSON.stringify({
    	"username": config.Jira_username,
    	"password": config.Jira_password
    });
	request.post({
		url:config.Host+'/rest/auth/1/session',
		headers: {
	    	'Content-Type': 'application/json',
	    	'Accept': 'application/json'
		},
		body: obj
	},
	function(error,response,body){
		if(!error && response.statusCode==200){
			res.send(JSON.parse(response.body));
		} else{
			res.status(response.statusCode);
			res.send({"status":response.statusCode,"error":error});
		}
	});
});

module.exports = router;